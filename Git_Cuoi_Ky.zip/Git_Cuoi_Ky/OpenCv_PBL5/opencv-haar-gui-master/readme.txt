numpy==1.15.2
opencv-contrib-python==3.4.3.18
opencv-python==3.4.3.18
pickle-mixin==1.0.2
Pillow==5.3.0
Pypubsub==4.0.0
six==1.11.0
typing==3.6.6
wxPython==4.0.3


built-in library:

json library:  config ini file
sys library: system

pip install ****:
cv2: opencv,pip install opencv-python,pip install opencv-contrib-python
pickle:pip install pickle-mixin
PIL: pillow,Python Imaging Library,pip install Pillow

Lưu ý: cần train dữ liệu trước khi chạy main.py
